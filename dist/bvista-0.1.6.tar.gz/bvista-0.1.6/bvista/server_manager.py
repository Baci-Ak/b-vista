import subprocess
import time
import requests
import os
import sys
import platform

API_URL = "http://127.0.0.1:5050"
_backend_started = False

def is_backend_running() -> bool:
    try:
        response = requests.get(f"{API_URL}/api/get_sessions", timeout=2)
        return response.status_code == 200
    except requests.RequestException:
        return False

def _validate_environment():
    if sys.version_info < (3, 7):
        print("⚠️ B-Vista requires Python 3.7 or higher.")
    if "dev" in platform.python_implementation().lower():
        print("⚠️ Running on a development build of Python. Consider switching to a stable release.")

def start_backend():
    global _backend_started
    if _backend_started:
        return
    _backend_started = True

    if is_backend_running():
        print("✅ B-Vista backend is already running.")
        return

    _validate_environment()
    print("🚀 Starting B-Vista backend...")

    backend_entry = "-m"
    backend_target = "backend.app"

    try:
        process = subprocess.Popen(
            [sys.executable, backend_entry, backend_target],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True
        )
    except Exception as e:
        print("❌ Failed to start backend subprocess.")
        print(f"🔴 Reason: {e}")
        return

    for _ in range(15):
        if is_backend_running():
            print("✅ B-Vista backend is now running.")
            return
        time.sleep(1)

    stdout, stderr = process.communicate()
    print("❌ Failed to start the backend.")
    print("🔴 Backend Logs (stdout):")
    print(stdout.decode() if stdout else "None")
    print("🔴 Backend Logs (stderr):")
    print(stderr.decode() if stderr else "None")
